package Steps;

import java.util.Timer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.*;

public class Login {

	WebDriver driver= null;

	@SuppressWarnings("deprecation")



	@Given("User launch Chrome browser")
	public void user_launch_chrome_browser() {
		String path= System.getProperty("user.dir");
		System.out.println("Path of project is "+path);
		// System.setProperty("webdriver.chrome.driver", path+"/Drivers/chromedriver.exe");
		System.setProperty("webdriver.ie.driver", path+"/Drivers/IEDriverServer.exe");
		driver = new InternetExplorerDriver(); 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	@When("User opens URL {string}")
	public void user_opens_url(String URL) {	
		driver.get(URL);	 	 
	}	

	@And("User enters Email as {string}")
	public void user_enters_email_as(String username) {
		driver.findElement(By.xpath("//input[@id='identifierId']")).sendKeys(username);

	}

	@And("User click on Next")
	public void user_click_on_next() {
		driver.findElement(By.xpath("//*[@id=\"identifierNext\"]/div/button/div[2]")).click();
	}

	@Then("User enters Password as {string}")
	public void user_enters_password_as(String pwd) {
		driver.findElement(By.name("password")).sendKeys(pwd);
	}

	@And("Click on Next")
	public void click_on_next() {
		driver.findElement(By.id("passwordNext")).click();

	}

	@Then("User login is successfully")
	public void user_login_is_successfully() throws InterruptedException {	 
		if (driver.findElement(By.xpath("//a[contains(text(),'Inbox')]")).isDisplayed()) 
		{
			System.out.println("User login is successful to Gmail");
		}
		else 
			System.out.println("User login failed");
		

	}

	@And("User click on Compose")
	public void user_click_on_compose() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//div[contains(text(),'Compose')]")).click();
	}

	@And("Compose Email window is displayed")
	public void compose_email_window_is_displayed() {
		if (driver.findElement(By.xpath("//textarea[@id=':8g']")).isDisplayed()) {
			System.out.println("Compose Email Window is displayed.");
		}
		else
			System.out.println("Compose Email Window is not displayed.");
	}

	@And("User Enters To field as {string}")
	public void user_enters_to_field_as(String To) {
		driver.findElement(By.xpath("//textarea[@id=':8g']")).sendKeys(To);

	}

	@And("Subject Line")
	public void subject_line() {
		driver.findElement(By.xpath("//input[@id=':7y']")).sendKeys("Incubyte");	  
	}

	@And("Email Body as {string}")
	public void email_body_hello_world(String EBody) {
		driver.findElement(By.xpath("//div[@id=':93']")).sendKeys(EBody);
	}
	@And("Click on send button")
	public void click_on_send_button() {
		driver.findElement(By.xpath("//div[@id=':7o']")).click();
	}	
	@Then("Message sent")
	public void message_sent() {
		if (driver.findElement(By.xpath("//span[contains(text(),'Message sent.')]")).isDisplayed()) {
			System.out.println("Email is sent successfully and the mesaage is displayed");
		}
		else
			System.out.println("Email is not sent");
	}
	
	@Then("User close browser")
	public void user_close_browser() {
	 	driver.close();
		driver.quit();
	}

}
